# Car Price Prediction (Machine Learning)

This project trains a regression model to predict car prices using features like brand_goodwill, horsepower, mileage, and age.

## How to Run
```
pip install -r requirements.txt
python src/train.py
```
